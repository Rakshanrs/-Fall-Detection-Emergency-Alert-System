# Fall Detection and Emergency Alert System for Elderly People

## Project description
An Arduino Uno prototype that uses an MPU6050 accelerometer/gyroscope to detect a possible fall using an impact threshold and a change in tilt. When the conditions are met, it activates a buzzer and red LED. A push button cancels the alarm.

> **Prototype note:** This version provides local buzzer/LED alerts. It does not send an SMS, make a phone call, or contact emergency services. It is not a medical or certified safety device.

## Components
- Arduino Uno
- MPU6050 module
- Buzzer
- Push button
- Red LED and green LED (with suitable current-limiting resistors)
- Breadboard, jumper wires, USB cable

## Connections
| Component | Arduino Uno |
|---|---|
| MPU6050 SDA | A4 |
| MPU6050 SCL | A5 |
| MPU6050 VCC | Module-rated supply (check the breakout board) |
| MPU6050 GND | GND |
| Buzzer | D8 |
| Cancel button | D7 to GND (uses `INPUT_PULLUP`) |
| Red LED | D9 through a current-limiting resistor |
| Green LED | D10 through a current-limiting resistor |
| Built-in LED | D13 |

## How it works
1. The MPU6050 is initialized and the device records a short still-position baseline.
2. The code monitors acceleration magnitude.
3. When the magnitude exceeds 2.5 g, it waits and checks the sensor again.
4. It estimates the tilt change from the baseline; a value above 45 degrees turns on the alarm.
5. Pressing the cancel button stops the buzzer and resets the LEDs.

## Upload and test
1. Open `Fall_Detection.ino` in Arduino IDE.
2. Select **Arduino Uno** as the board and the correct port.
3. Upload the sketch.
4. Open Serial Monitor at **9600 baud**.
5. Keep the sensor still during startup calibration, then test carefully.

## Repository contents
- `Fall_Detection.ino` — Arduino sketch
- `images/circuit_diagram.png` — supplied project circuit diagram
- `images/serial_output_example.png` — supplied serial output example

## Limitations
This is a demonstration prototype. Thresholds may need calibration for the mounting position and sensor. False positives and missed detections are possible. Do not rely on it as the only means of protecting an elderly person.
