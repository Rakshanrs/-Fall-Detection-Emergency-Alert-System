#include <Wire.h>

const int MPU = 0x68;
const int BUZZ = 8;
const int BTN = 7;
const int LED = 13;
const int GREEN = 10;
const int RED = 9;

float bx = 0, by = 0, bz = 1;
bool alarmOn = false;
unsigned long lastPrint = 0;

bool readMPU(float &x, float &y, float &z) {
  Wire.beginTransmission(MPU);
  Wire.write(0x3B);
  Wire.endTransmission(false);
  Wire.requestFrom((uint8_t)MPU, (uint8_t)6, (uint8_t)true);
  if (Wire.available() < 6) return false;
  int16_t rx = Wire.read() << 8 | Wire.read();
  int16_t ry = Wire.read() << 8 | Wire.read();
  int16_t rz = Wire.read() << 8 | Wire.read();
  x = rx / 4096.0;
  y = ry / 4096.0;
  z = rz / 4096.0;
  return true;
}

void setup() {
  Serial.begin(9600);
  pinMode(BTN, INPUT_PULLUP);
  pinMode(LED, OUTPUT);
  pinMode(GREEN, OUTPUT);
  pinMode(RED, OUTPUT);
  Wire.begin();
  Wire.beginTransmission(MPU);
  Wire.write(0x6B);
  Wire.write(0);
  Wire.endTransmission(true);
  Wire.beginTransmission(MPU);
  Wire.write(0x1C);
  Wire.write(0x10);
  Wire.endTransmission(true);
  Serial.println("Hold still for 3 seconds...");
  delay(3000);
  float x, y, z, sx = 0, sy = 0, sz = 0;
  for (int i = 0; i < 10; i++) {
    if (readMPU(x, y, z)) { sx += x; sy += y; sz += z; }
    delay(50);
  }
  float m = sqrt(sx * sx + sy * sy + sz * sz);
  if (m > 0) { bx = sx / m; by = sy / m; bz = sz / m; }
  digitalWrite(GREEN, HIGH);
  Serial.println("Ready");
}

void loop() {
  float x, y, z;
  if (!readMPU(x, y, z)) {
    Serial.println("No data");
    delay(500);
    return;
  }
  float g = sqrt(x * x + y * y + z * z);

  if (!alarmOn && g > 2.5) {
    delay(1500);
    if (readMPU(x, y, z)) {
      float g2 = sqrt(x * x + y * y + z * z);
      if (g2 > 0.3) {
        float c = (x * bx + y * by + z * bz) / g2;
        if (c > 1) c = 1;
        if (c < -1) c = -1;
        float angle = acos(c) * 57.3;
        Serial.print("Impact, tilt change = ");
        Serial.println(angle);
        if (angle > 45) alarmOn = true;
      }
    }
  }

  if (alarmOn) {
    tone(BUZZ, 2000);
    digitalWrite(LED, HIGH);
    digitalWrite(RED, HIGH);
    digitalWrite(GREEN, LOW);
    if (millis() - lastPrint > 1000) {
      Serial.println("FALL DETECTED");
      lastPrint = millis();
    }
    if (digitalRead(BTN) == LOW) {
      alarmOn = false;
      noTone(BUZZ);
      digitalWrite(LED, LOW);
      digitalWrite(RED, LOW);
      digitalWrite(GREEN, HIGH);
      Serial.println("Cancelled");
    }
  } else {
    if (millis() - lastPrint > 1000) {
      Serial.println("Normal");
      lastPrint = millis();
    }
  }
  delay(20);
}
